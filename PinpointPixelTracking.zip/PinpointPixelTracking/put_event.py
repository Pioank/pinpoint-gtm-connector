import boto3
import datetime
import time
import os

client = boto3.client('pinpoint')
application_id = os.environ['PINPOINT_APP_ID']

def pinpoint_put_event(event_name, endpoint_id, user_attributes, event_attributes):
    response = client.put_events(
            ApplicationId = application_id,
            EventsRequest={
                'BatchItem': {
                    endpoint_id: {
                        'Endpoint': {
                            'User': {
                                'UserAttributes': user_attributes,
                            }
                        },
                        'Events':{
                            'Event': {
                                'EventType': event_name,
                                'Attributes': event_attributes,
                                'Timestamp': datetime.datetime.fromtimestamp(time.time()).isoformat()
                            }
                        }
                    }
                } 
            }
        )
    print(response)
    return response