from urllib.parse import urlparse, parse_qs
import re
from put_event import pinpoint_put_event

def lambda_handler(event, context):
  
  for record in event['Records']:
    body = record['body']
    querystring=re.search(r'querystring=(.*?)}', body).group(1)
    querystring=querystring.replace("{", "?")
    querystring=querystring.replace(", ", "&")
    parsed_url = urlparse(querystring)
    querystring=parse_qs(parsed_url.query)
    event_attributes_list = {}
    user_attributes_list = {}
    
    try:
      event_name = querystring['event'][0]
      endpoint_id = querystring['endpoint_id'][0]
      del querystring['event']
      del querystring['endpoint_id']
        
    except Exception as e: 
      print(e)
      print("There was no event_name or endpoint_id")
    else:
      # The application scans if there are any URL parameters that start with evat or usat
      for key, value in querystring.items():
        if key[:4] == "usat":
          user_attributes_list.update([(key[5:],value)])
        elif key[:4] == "evat":
          event_attributes_list.update([(key[5:],value[0])])
        else:
          print("Not a valid URL parameter: " + str(key) + ":" + value[0])
      pinpoint_put_event(event_name, endpoint_id, user_attributes_list, event_attributes_list)

  
